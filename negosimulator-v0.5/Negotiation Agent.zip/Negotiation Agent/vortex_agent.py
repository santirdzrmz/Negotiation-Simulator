"""
VortexAgent — Improved negotiating agent combining all enhancements.

Built on top of AdaptiveAgent's dynamic-target-value architecture, with
the following additions:

1. Real opponent utility model (ImprovedFrequencyAnalysis)
   No peeking at the opponent's true utility function.  Uses time-weighted
   frequency analysis with normalised weights.

2. Regression-based opponent strategy model (RegressionStrategyModel)
   Fits a linear regression to ALL received utilities over time, giving a
   better prediction of where the opponent will be at the deadline than the
   simple "highest received, linearly extrapolated" approach.

3. Nash product bid selection
   Among offers above the aspiration level, picks the one maximising
   (my_utility × estimated_opponent_utility), steering proposals to the
   Pareto frontier.

4. Reproposing
   Before proposing a new (lower-utility) offer, checks whether any offer
   at the same utility level has already been proposed by the opponent.
   If yes, proposes that one — costs us nothing, and may be accepted
   immediately.

5. Forward-looking acceptance
   If the regression model predicts that the opponent will not improve their
   offer enough before the deadline, accepts the current offer rather than
   waiting in vain.

6. Self-mirroring concession control
   Tracks our own concession speed vs the opponent's.  If we are conceding
   much faster, slows down our aspiration drop to avoid being exploited.

7. Panic acceptance near the deadline
   Accepts anything above the reservation value in the final few percent of
   time to avoid a no-deal outcome.

8. Domain-size adaptation
   Adjusts the minimum target utility and panic threshold based on how many
   offers exist above the reservation value.  Small domains require more
   flexibility; large ones afford more selectivity.
"""

from agents import Agent
from domains import OfferSpace, UtilityFunction
from improved_opponent_models import ImprovedFrequencyAnalysis, RegressionStrategyModel


class VortexAgent(Agent):

    def __init__(
        self,
        offer_space: OfferSpace,
        utility_function: UtilityFunction,
        reservation_value: float,
        agent_index: int,
        concession_param: float = 0.2,
        agent_name: str = "VortexAgent",
    ):
        super().__init__(offer_space, utility_function, reservation_value, agent_index, agent_name)

        self.concession_param = concession_param

        # ---- Opponent models ----
        self.opponent_utility_model  = ImprovedFrequencyAnalysis(offer_space)
        self.opponent_strategy_model = RegressionStrategyModel(offer_space, utility_function)

        # ---- Pre-compute offer list sorted by own utility (descending) ----
        all_offers = offer_space.get_all_offers()
        self.offers_sorted = sorted(all_offers, key=utility_function.get_utility, reverse=True)
        self.max_offer = self.offers_sorted[0]
        self.init_value = utility_function.get_utility(self.max_offer)

        # ---- Proposal tracking ----
        self.proposed_by_me:       set = set()
        self.proposed_by_opponent: set = set()

        # For self-mirroring: track utility of each own proposal over time.
        self.my_proposal_history:  list[tuple[float, float]] = []  # (time, util)

        # ---- Domain-size adaptation ----
        # min_target: we never concede below this, regardless of what the
        # opponent strategy model predicts.  Set high enough that we don't
        # get exploited by tough opponents who concede slowly.
        # panic_threshold: only accept anything above rv in the last few %.
        n_above_rv = sum(
            1 for o in all_offers
            if utility_function.get_utility(o) > reservation_value
        )
        if n_above_rv < 10:
            self.min_target      = max(reservation_value, 0.50)
            self.panic_threshold = 0.95
        elif n_above_rv < 50:
            self.min_target      = max(reservation_value, 0.45)
            self.panic_threshold = 0.95
        else:
            self.min_target      = max(reservation_value, 0.40)
            self.panic_threshold = 0.95

    # -----------------------------------------------------------------------
    # Main decision method
    # -----------------------------------------------------------------------

    def choose_action(self, current_time: float, received_offer):

        # ---- 1. Update opponent models ----
        if received_offer is not None:
            self.opponent_utility_model.update(received_offer, current_time)
            self.opponent_strategy_model.update(received_offer, current_time)
            self.proposed_by_opponent.add(received_offer)

        approx_opp_util = self.opponent_utility_model.get_approximate_utility_function()

        # ---- 2. Dynamic target value (AdaptiveAgent core) ----
        target_time  = max(self.deadline * 0.95, current_time)
        target_value = self._compute_target(current_time, target_time)

        # ---- 3. Self-mirroring: slow down if we're conceding too fast ----
        target_value = self._apply_self_mirror(current_time, target_value)

        # ---- 4. Aspiration level ----
        aspiration = self._aspiration(current_time, target_time, target_value)

        # ---- 5. Select bid (Nash product + reproposing) ----
        next_offer = self._select_bid(aspiration, approx_opp_util)

        # ---- 6. Acceptance decision ----
        accept = self._should_accept(
            received_offer, aspiration, next_offer, current_time, target_value
        )

        # ---- 7. Return action ----
        if accept:
            return ("accept", received_offer)
        else:
            util_proposed = self.utility_function.get_utility(next_offer)
            self.my_proposal_history.append((current_time, util_proposed))
            self.proposed_by_me.add(next_offer)
            return ("propose", next_offer)

    # -----------------------------------------------------------------------
    # Dynamic target (AdaptiveAgent core logic)
    # -----------------------------------------------------------------------

    def _compute_target(self, current_time: float, target_time: float) -> float:
        if current_time == 0:
            return self.init_value

        predicted = self.opponent_strategy_model.predict(current_time, target_time)
        return max(predicted, self.min_target)

    # -----------------------------------------------------------------------
    # Self-mirroring
    # -----------------------------------------------------------------------

    def _apply_self_mirror(self, current_time: float, target_value: float) -> float:
        """
        Compare own concession speed to opponent's.  If we are conceding more
        than twice as fast, raise the target value to slow ourselves down.
        """
        if current_time < 1.0 or len(self.my_proposal_history) < 2:
            return target_value

        # Own concession speed: drop in our proposal utility per second.
        my_start_util = self.my_proposal_history[0][1]
        my_now_util   = self.my_proposal_history[-1][1]
        my_speed = max(0.0, (my_start_util - my_now_util) / current_time)

        # Opponent concession speed: rise in the utility we receive, per second.
        opp_data = self.opponent_strategy_model.data_points
        if len(opp_data) < 2:
            return target_value

        opp_start_util = opp_data[0][1]
        opp_now_util   = opp_data[-1][1]
        opp_speed = max(0.0, (opp_now_util - opp_start_util) / current_time)

        # If we are conceding more than twice as fast, raise the target.
        if my_speed > 2.0 * opp_speed + 1e-6:
            # Nudge target up by 10 % of the gap between target and init.
            adjustment = 0.10 * (self.init_value - target_value)
            target_value = min(self.init_value, target_value + adjustment)

        return target_value

    # -----------------------------------------------------------------------
    # Aspiration function
    # -----------------------------------------------------------------------

    def _aspiration(self, current_time: float, target_time: float, target_value: float) -> float:
        exponent = 1.0 - (current_time / target_time)

        if self.concession_param == 1:
            return (self.init_value - target_value) * exponent + target_value
        else:
            return (
                (self.init_value - target_value)
                * (1 - self.concession_param ** exponent)
                / (1 - self.concession_param)
                + target_value
            )

    # -----------------------------------------------------------------------
    # Bid selection: Nash product + reproposing
    # -----------------------------------------------------------------------

    def _select_bid(self, aspiration: float, approx_opp_util):
        """
        Step 1 — find the best offer above aspiration by Nash product.
        Step 2 — reproposing: if an equal-utility offer has been proposed
                 by the opponent and not yet by us, switch to that one.
        """

        # Step 1: Nash product search.
        best_offer = None
        best_score = -1.0
        best_my_util = -1.0

        for offer in self.offers_sorted:
            my_util = self.utility_function.get_utility(offer)

            if my_util < aspiration:
                break  # list is sorted descending — nothing below qualifies.

            if my_util <= self.reservation_value:
                continue

            if offer in self.proposed_by_me:
                continue

            if approx_opp_util is not None:
                opp_util = approx_opp_util.get_utility(offer)
                score    = my_util * opp_util          # Nash product
            else:
                score = my_util                        # no model yet

            if score > best_score:
                best_score    = score
                best_offer    = offer
                best_my_util  = my_util

        if best_offer is None:
            best_offer   = self.max_offer
            best_my_util = self.init_value

        # Step 2: Reproposing.
        # Look for any offer in proposed_by_opponent that:
        #   - has the same utility as best_offer (within a small tolerance), AND
        #   - has not yet been proposed by us.
        # If found, use it instead — it is equally good for us but already
        # validated by the opponent, so acceptance is more likely.
        TOLERANCE = 1e-9
        for opp_offer in self.proposed_by_opponent:
            opp_my_util = self.utility_function.get_utility(opp_offer)
            if (
                abs(opp_my_util - best_my_util) <= TOLERANCE
                and opp_offer not in self.proposed_by_me
            ):
                best_offer = opp_offer
                break

        return best_offer

    # -----------------------------------------------------------------------
    # Acceptance strategy
    # -----------------------------------------------------------------------

    def _should_accept(
        self,
        received_offer,
        aspiration: float,
        next_offer,
        current_time: float,
        target_value: float,
    ) -> bool:

        if received_offer is None:
            return False

        util_received = self.utility_function.get_utility(received_offer)

        # Never accept at or below reservation value.
        if util_received <= self.reservation_value:
            return False

        # --- Panic mode ---
        if current_time >= self.panic_threshold * self.deadline:
            return True

        # --- Forward-looking acceptance ---
        # Only activate after we have enough data (>= 5 proposals) and
        # at least 20% of the deadline has passed — early predictions are
        # unreliable and accepting too soon is very costly.
        # Crucially, the received offer must ALSO meet the aspiration level:
        # if the opponent won't improve but their offer is still below our
        # aspiration, we should walk away, not capitulate.
        enough_data    = len(self.opponent_strategy_model.data_points) >= 5
        past_early     = current_time >= 0.20 * self.deadline
        if enough_data and past_early:
            predicted_best = self.opponent_strategy_model.predict(
                current_time, self.deadline * 0.95
            )
            if util_received >= predicted_best - 1e-6 and util_received >= aspiration:
                return True

        # --- Normal mode ---
        # Accept if at or above aspiration AND at least as good as our next proposal.
        util_next = self.utility_function.get_utility(next_offer)
        return util_received >= aspiration and util_received >= util_next
